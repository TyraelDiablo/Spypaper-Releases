tag @s add pk_here
spawnpoint @s ~ ~ ~
title @s actionbar {"text":"✔ Kontrol noktası","color":"gold"}
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.6
