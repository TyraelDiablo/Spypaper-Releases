execute as @a[gamemode=adventure] at @s if block ~ ~-1 ~ minecraft:gold_block unless entity @s[tag=pk_here] run function parkur:checkpoint
execute as @a[tag=pk_here] at @s unless block ~ ~-1 ~ minecraft:gold_block run tag @s remove pk_here
execute as @a[gamemode=adventure] at @s if block ~ ~-1 ~ minecraft:diamond_block unless score @s pk_done matches 1.. run function parkur:finish
execute as @a[gamemode=adventure] at @s if block ~ ~-1 ~ minecraft:emerald_block run scoreboard players reset @s pk_done
execute as @a at @s if entity @s[y=-200,dy=230] run function parkur:respawn
