scoreboard players set @s pk_done 1
title @s title {"text":"Tebrikler!","color":"gold","bold":true}
title @s subtitle {"text":"Parkuru bitirdin","color":"yellow"}
tellraw @a [{"selector":"@s","color":"gold"},{"text":" parkuru bitirdi!","color":"yellow"}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~
spawnpoint @s 0 65 0
