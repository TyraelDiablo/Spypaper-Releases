scoreboard objectives add pk_done dummy
scoreboard objectives add pk_cp dummy
