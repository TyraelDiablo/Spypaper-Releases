scoreboard players add #count ob 1
execute if score #count ob matches 60 run tellraw @a [{"text":"✦ OneBlock: ","color":"gold"},{"text":"Mağara","color":"yellow","bold":true}]
execute if score #count ob matches 60 run playsound minecraft:ui.toast.challenge_complete master @a 0 65 0
execute if score #count ob matches 180 run tellraw @a [{"text":"✦ OneBlock: ","color":"gold"},{"text":"Çöl","color":"yellow","bold":true}]
execute if score #count ob matches 180 run playsound minecraft:ui.toast.challenge_complete master @a 0 65 0
execute if score #count ob matches 320 run tellraw @a [{"text":"✦ OneBlock: ","color":"gold"},{"text":"Okyanus","color":"yellow","bold":true}]
execute if score #count ob matches 320 run playsound minecraft:ui.toast.challenge_complete master @a 0 65 0
execute if score #count ob matches 480 run tellraw @a [{"text":"✦ OneBlock: ","color":"gold"},{"text":"Nether","color":"yellow","bold":true}]
execute if score #count ob matches 480 run playsound minecraft:ui.toast.challenge_complete master @a 0 65 0
execute if score #count ob matches 700 run tellraw @a [{"text":"✦ OneBlock: ","color":"gold"},{"text":"Derinlik","color":"yellow","bold":true}]
execute if score #count ob matches 700 run playsound minecraft:ui.toast.challenge_complete master @a 0 65 0
execute if score #count ob matches 1000 run tellraw @a [{"text":"✦ OneBlock: ","color":"gold"},{"text":"End","color":"yellow","bold":true}]
execute if score #count ob matches 1000 run playsound minecraft:ui.toast.challenge_complete master @a 0 65 0
execute store result score #m ob run scoreboard players get #count ob
scoreboard players operation #m ob %= #40 ob
execute if score #m ob matches 0 run return run function oneblock:chest
execute if score #count ob matches 1000.. run return run function oneblock:phase6
execute if score #count ob matches 700.. run return run function oneblock:phase5
execute if score #count ob matches 480.. run return run function oneblock:phase4
execute if score #count ob matches 320.. run return run function oneblock:phase3
execute if score #count ob matches 180.. run return run function oneblock:phase2
execute if score #count ob matches 60.. run return run function oneblock:phase1
execute if score #count ob matches 0.. run return run function oneblock:phase0
