execute if block 0 64 0 minecraft:air run function oneblock:next
