execute store result score #r ob run random value 1..100
execute if score #r ob matches 1..25 run setblock 0 64 0 minecraft:prismarine
execute if score #r ob matches 26..40 run setblock 0 64 0 minecraft:sand
execute if score #r ob matches 41..55 run setblock 0 64 0 minecraft:gravel
execute if score #r ob matches 56..67 run setblock 0 64 0 minecraft:clay
execute if score #r ob matches 68..77 run setblock 0 64 0 minecraft:dark_prismarine
execute if score #r ob matches 78..85 run setblock 0 64 0 minecraft:sea_lantern
execute if score #r ob matches 86..93 run setblock 0 64 0 minecraft:sponge
execute if score #r ob matches 94..100 run setblock 0 64 0 minecraft:packed_ice
execute store result score #s ob run random value 1..12
execute if score #s ob matches 1 run summon minecraft:drowned 0.5 65.2 0.5
execute if score #s ob matches 2 run summon minecraft:turtle 0.5 65.2 0.5
execute if score #s ob matches 3 run summon minecraft:axolotl 0.5 65.2 0.5
