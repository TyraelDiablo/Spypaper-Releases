execute store result score #r ob run random value 1..100
execute if score #r ob matches 1..30 run setblock 0 64 0 minecraft:stone
execute if score #r ob matches 31..42 run setblock 0 64 0 minecraft:cobblestone
execute if score #r ob matches 43..52 run setblock 0 64 0 minecraft:andesite
execute if score #r ob matches 53..60 run setblock 0 64 0 minecraft:coal_ore
execute if score #r ob matches 61..68 run setblock 0 64 0 minecraft:iron_ore
execute if score #r ob matches 69..76 run setblock 0 64 0 minecraft:copper_ore
execute if score #r ob matches 77..82 run setblock 0 64 0 minecraft:gravel
execute if score #r ob matches 83..87 run setblock 0 64 0 minecraft:granite
execute if score #r ob matches 88..92 run setblock 0 64 0 minecraft:diorite
execute if score #r ob matches 93..96 run setblock 0 64 0 minecraft:lapis_ore
execute if score #r ob matches 97..100 run setblock 0 64 0 minecraft:redstone_ore
execute store result score #s ob run random value 1..12
execute if score #s ob matches 1 run summon minecraft:zombie 0.5 65.2 0.5
execute if score #s ob matches 2 run summon minecraft:skeleton 0.5 65.2 0.5
execute if score #s ob matches 3 run summon minecraft:spider 0.5 65.2 0.5
execute if score #s ob matches 4 run summon minecraft:bat 0.5 65.2 0.5
