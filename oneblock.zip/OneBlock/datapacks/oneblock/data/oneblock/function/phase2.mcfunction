execute store result score #r ob run random value 1..100
execute if score #r ob matches 1..30 run setblock 0 64 0 minecraft:sand
execute if score #r ob matches 31..45 run setblock 0 64 0 minecraft:sandstone
execute if score #r ob matches 46..57 run setblock 0 64 0 minecraft:red_sand
execute if score #r ob matches 58..67 run setblock 0 64 0 minecraft:terracotta
execute if score #r ob matches 68..75 run setblock 0 64 0 minecraft:gold_ore
execute if score #r ob matches 76..83 run setblock 0 64 0 minecraft:cactus
execute if score #r ob matches 84..90 run setblock 0 64 0 minecraft:sand
execute if score #r ob matches 91..95 run setblock 0 64 0 minecraft:orange_terracotta
execute if score #r ob matches 96..100 run setblock 0 64 0 minecraft:clay
execute store result score #s ob run random value 1..12
execute if score #s ob matches 1 run summon minecraft:husk 0.5 65.2 0.5
execute if score #s ob matches 2 run summon minecraft:rabbit 0.5 65.2 0.5
execute if score #s ob matches 3 run summon minecraft:camel 0.5 65.2 0.5
