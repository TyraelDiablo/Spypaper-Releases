scoreboard objectives add ob dummy
scoreboard players add #count ob 0
scoreboard players add #phase ob 0
scoreboard players set #40 ob 40
