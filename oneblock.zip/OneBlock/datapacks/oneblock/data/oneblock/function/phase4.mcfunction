execute store result score #r ob run random value 1..100
execute if score #r ob matches 1..30 run setblock 0 64 0 minecraft:netherrack
execute if score #r ob matches 31..42 run setblock 0 64 0 minecraft:soul_sand
execute if score #r ob matches 43..52 run setblock 0 64 0 minecraft:nether_quartz_ore
execute if score #r ob matches 53..62 run setblock 0 64 0 minecraft:nether_gold_ore
execute if score #r ob matches 63..70 run setblock 0 64 0 minecraft:magma_block
execute if score #r ob matches 71..78 run setblock 0 64 0 minecraft:glowstone
execute if score #r ob matches 79..86 run setblock 0 64 0 minecraft:crimson_nylium
execute if score #r ob matches 87..94 run setblock 0 64 0 minecraft:warped_nylium
execute if score #r ob matches 95..98 run setblock 0 64 0 minecraft:blackstone
execute if score #r ob matches 99..100 run setblock 0 64 0 minecraft:ancient_debris
execute store result score #s ob run random value 1..12
execute if score #s ob matches 1 run summon minecraft:zombified_piglin 0.5 65.2 0.5
execute if score #s ob matches 2 run summon minecraft:magma_cube 0.5 65.2 0.5
execute if score #s ob matches 3 run summon minecraft:strider 0.5 65.2 0.5
