execute store result score #r ob run random value 1..100
execute if score #r ob matches 1..30 run setblock 0 64 0 minecraft:grass_block
execute if score #r ob matches 31..50 run setblock 0 64 0 minecraft:dirt
execute if score #r ob matches 51..64 run setblock 0 64 0 minecraft:oak_log
execute if score #r ob matches 65..72 run setblock 0 64 0 minecraft:oak_leaves
execute if score #r ob matches 73..78 run setblock 0 64 0 minecraft:birch_log
execute if score #r ob matches 79..84 run setblock 0 64 0 minecraft:coarse_dirt
execute if score #r ob matches 85..89 run setblock 0 64 0 minecraft:pumpkin
execute if score #r ob matches 90..94 run setblock 0 64 0 minecraft:melon
execute if score #r ob matches 95..97 run setblock 0 64 0 minecraft:moss_block
execute if score #r ob matches 98..100 run setblock 0 64 0 minecraft:clay
execute store result score #s ob run random value 1..12
execute if score #s ob matches 1 run summon minecraft:chicken 0.5 65.2 0.5
execute if score #s ob matches 2 run summon minecraft:cow 0.5 65.2 0.5
execute if score #s ob matches 3 run summon minecraft:sheep 0.5 65.2 0.5
execute if score #s ob matches 4 run summon minecraft:pig 0.5 65.2 0.5
