execute store result score #r ob run random value 1..100
execute if score #r ob matches 1..40 run setblock 0 64 0 minecraft:end_stone
execute if score #r ob matches 41..60 run setblock 0 64 0 minecraft:obsidian
execute if score #r ob matches 61..70 run setblock 0 64 0 minecraft:purpur_block
execute if score #r ob matches 71..80 run setblock 0 64 0 minecraft:end_stone_bricks
execute if score #r ob matches 81..88 run setblock 0 64 0 minecraft:deepslate_emerald_ore
execute if score #r ob matches 89..94 run setblock 0 64 0 minecraft:deepslate_diamond_ore
execute if score #r ob matches 95..100 run setblock 0 64 0 minecraft:crying_obsidian
execute store result score #s ob run random value 1..12
execute if score #s ob matches 1 run summon minecraft:enderman 0.5 65.2 0.5
execute if score #s ob matches 2 run summon minecraft:shulker 0.5 65.2 0.5
