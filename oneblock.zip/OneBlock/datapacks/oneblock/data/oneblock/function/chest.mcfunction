setblock 0 64 0 minecraft:chest
execute store result score #c ob run random value 1..2
execute if score #c ob matches 1 run data modify block 0 64 0 Items set value [{Slot:0b,id:"minecraft:oak_sapling",count:2},{Slot:1b,id:"minecraft:bone_meal",count:4},{Slot:2b,id:"minecraft:water_bucket",count:1},{Slot:3b,id:"minecraft:lava_bucket",count:1},{Slot:4b,id:"minecraft:wheat_seeds",count:4},{Slot:5b,id:"minecraft:sugar_cane",count:2}]
execute if score #c ob matches 2 run data modify block 0 64 0 Items set value [{Slot:0b,id:"minecraft:bread",count:4},{Slot:1b,id:"minecraft:iron_ingot",count:3},{Slot:2b,id:"minecraft:torch",count:8},{Slot:3b,id:"minecraft:string",count:3},{Slot:4b,id:"minecraft:cobblestone",count:16},{Slot:5b,id:"minecraft:ice",count:2}]
tellraw @a [{"text":"✦ OneBlock: ","color":"gold"},{"text":"Sandık!","color":"yellow"}]
