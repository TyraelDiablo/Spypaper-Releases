execute store result score #r ob run random value 1..100
execute if score #r ob matches 1..30 run setblock 0 64 0 minecraft:deepslate
execute if score #r ob matches 31..42 run setblock 0 64 0 minecraft:tuff
execute if score #r ob matches 43..52 run setblock 0 64 0 minecraft:deepslate_iron_ore
execute if score #r ob matches 53..60 run setblock 0 64 0 minecraft:deepslate_gold_ore
execute if score #r ob matches 61..68 run setblock 0 64 0 minecraft:deepslate_redstone_ore
execute if score #r ob matches 69..76 run setblock 0 64 0 minecraft:deepslate_lapis_ore
execute if score #r ob matches 77..84 run setblock 0 64 0 minecraft:deepslate_diamond_ore
execute if score #r ob matches 85..90 run setblock 0 64 0 minecraft:amethyst_block
execute if score #r ob matches 91..95 run setblock 0 64 0 minecraft:calcite
execute if score #r ob matches 96..100 run setblock 0 64 0 minecraft:obsidian
execute store result score #s ob run random value 1..12
execute if score #s ob matches 1 run summon minecraft:zombie 0.5 65.2 0.5
execute if score #s ob matches 2 run summon minecraft:creeper 0.5 65.2 0.5
execute if score #s ob matches 3 run summon minecraft:enderman 0.5 65.2 0.5
